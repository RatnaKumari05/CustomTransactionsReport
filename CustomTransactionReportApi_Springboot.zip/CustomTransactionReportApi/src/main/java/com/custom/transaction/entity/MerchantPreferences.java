package com.custom.transaction.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "merchantpreferences")
public class MerchantPreferences {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mpid")
	private int merchantPrefId;
	@Column(name = "merchantid")
	private int merchantId;
	@Column(name = "pincode")
	private long pincode;
	@Column(name = "upperlimit")
	private double upperLimit;
	@Column(name = "lowerlimit")
	private double lowerLimit;
	@Column(name = "custname")
	private String custName;

	public MerchantPreferences() {
	}

	public MerchantPreferences(int merchantPrefId, int merchantId, long pincode, double upperLimit, double lowerLimit,
			String custName) {
		super();
		this.merchantPrefId = merchantPrefId;
		this.merchantId = merchantId;
		this.pincode = pincode;
		this.upperLimit = upperLimit;
		this.lowerLimit = lowerLimit;
		this.custName = custName;
	}

	public int getMerchantPrefId() {
		return merchantPrefId;
	}

	public void setMerchantPrefId(int merchantPrefId) {
		this.merchantPrefId = merchantPrefId;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public double getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(double upperLimit) {
		this.upperLimit = upperLimit;
	}

	public double getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(double lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	@Override
	public String toString() {
		return "MerchantPreferences [merchantPrefId=" + merchantPrefId + ", merchantId=" + merchantId + ", pincode="
				+ pincode + ", upperLimit=" + upperLimit + ", lowerLimit=" + lowerLimit + ", custName=" + custName
				+ "]";
	}

	
}
