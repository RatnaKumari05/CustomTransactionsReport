package com.custom.transaction.entity;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "transactions")
public class CustomTransaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "transactionid")
	private int transactionId;
	@Column(name = "custid")
	private int custId;
	@Column(name = "custname")
	private String custName;
	@Column(name = "merchantid")
	private int merchantId;
	@Column(name = "billingaddress")
	private String billingAddress;
	@Column(name = "timestamps")
	private String timeStamp;
	@Column(name = "pincode")
	private long pincode;
	@Column(name = "transactionamount")
	private double transactionAmount;
	@OneToMany
	@JoinColumn(name = "transactionid")
	private List<TransactionCart> TransactionCart;

	public CustomTransaction() {
		super();
	}

	public CustomTransaction(int transactionId, int custId, String custName, int merchantId, String billingAddress,
			String timeStamp, long pincode, double transactionAmount,
			List<com.custom.transaction.entity.TransactionCart> transactionCart) {
		super();
		this.transactionId = transactionId;
		this.custId = custId;
		this.custName = custName;
		this.merchantId = merchantId;
		this.billingAddress = billingAddress;
		this.timeStamp = timeStamp;
		this.pincode = pincode;
		this.transactionAmount = transactionAmount;
		TransactionCart = transactionCart;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public String getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public List<TransactionCart> getTransactionCart() {
		return TransactionCart;
	}

	public void setTransactionCart(List<TransactionCart> transactionCart) {
		TransactionCart = transactionCart;
	}

	@Override
	public String toString() {
		return "CustomTransaction [transactionId=" + transactionId + ", custId=" + custId + ", custName=" + custName
				+ ", merchantId=" + merchantId + ", billingAddress=" + billingAddress + ", timeStamp=" + timeStamp
				+ ", pincode=" + pincode + ", transactionAmount=" + transactionAmount + ", TransactionCart="
				+ TransactionCart + "]";
	}

	
}
