package com.custom.transaction.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "transactioncart")
public class TransactionCart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "tpid")
	private int transProductId;
	@ManyToOne
	@JoinColumn(name = "transactionid")
	private CustomTransaction customTransaction;
	@OneToOne
	@JoinColumn(name = "productid")
	private Product product;

	public TransactionCart() {

	}

	public TransactionCart(int transProductId, CustomTransaction customTransaction, Product product) {
		super();
		this.transProductId = transProductId;
		this.customTransaction = customTransaction;
		this.product = product;
	}

	public int getTransProductId() {
		return transProductId;
	}

	public void setTransProductId(int transProductId) {
		this.transProductId = transProductId;
	}

	public CustomTransaction getCustomTransaction() {
		return customTransaction;
	}

	public void setCustomTransaction(CustomTransaction customTransaction) {
		this.customTransaction = customTransaction;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "TransactionCart [transProductId=" + transProductId + ", customTransaction=" + customTransaction
				+ ", product=" + product + "]";
	}

}
