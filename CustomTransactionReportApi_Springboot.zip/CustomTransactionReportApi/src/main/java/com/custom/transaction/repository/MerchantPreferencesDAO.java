package com.custom.transaction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestParam;

import com.custom.transaction.entity.CustomTransaction;
import com.custom.transaction.entity.MerchantPreferences;

@RepositoryRestResource(path = "merchantPreferences")
@CrossOrigin("http://localhost:4200/")
public interface MerchantPreferencesDAO extends JpaRepository<MerchantPreferences, Integer> {

	List<MerchantPreferences> findByUpperLimit(@RequestParam("upperLimit") Double upperLimit);

	List<MerchantPreferences> findByLowerLimit(@RequestParam("lowerLimit") Double lowerLimit);

	List<MerchantPreferences> findByPincode(@RequestParam("pincode") Long pincode);

	List<MerchantPreferences> findByCustName(@RequestParam("custName") String custName);
	
	@Query(value = "select * from merchantpreferences where merchantid like  %:merchantId%", nativeQuery = true)
	List<MerchantPreferences> findByMerchantId(@RequestParam("merchantId") int merchantId);

}
