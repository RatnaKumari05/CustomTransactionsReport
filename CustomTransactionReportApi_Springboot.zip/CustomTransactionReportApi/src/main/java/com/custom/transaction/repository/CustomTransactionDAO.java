package com.custom.transaction.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestParam;

import com.custom.transaction.entity.CustomTransaction;

@RepositoryRestResource(path = "transactions")
@CrossOrigin("http://localhost:4200/")
public interface CustomTransactionDAO extends JpaRepository<CustomTransaction, Integer> {
	@Query(value = "select * from transactions t where t.timestamps between  :timestamp1 and :timestamp2", nativeQuery = true)
	List<CustomTransaction> findByTimeStamp(@RequestParam("timestamp1") String timestamp1,
			@RequestParam("timestamp2") String timestamp2);

	List<CustomTransaction> findByMerchantIdAndPincode(@RequestParam("merchantId") int merchantId,
			@RequestParam("pincode") Long pincode);

	List<CustomTransaction> findByMerchantIdAndCustName(@RequestParam("merchantId") int merchantId,
			@RequestParam("custName") String custName);

	List<CustomTransaction> findByMerchantIdAndPincodeAndCustName(@RequestParam("merchantId") int merchantId,
			@RequestParam("pincode") Long pincode, @RequestParam("custName") String custName);

	@Query(value = "select * from transactions t where t.merchantId like  %:merchantId%", nativeQuery = true)
	List<CustomTransaction> findBymerchantId(@RequestParam("merchantId") int merchantId);

	List<CustomTransaction> findByMerchantIdAndTransactionAmountAndPincode(@RequestParam("merchantId") int merchantId,
			@RequestParam("transactionAmount") Double transactionAmount, @RequestParam("pincode") int pincode);

	@Query(value = "select * from transactions t where t.merchantid like  %:merchantId% and transactionamount >:transactionAmount and t.custname like %:custName%", nativeQuery = true)
	List<CustomTransaction> findByMerchantIdAndTransactionAmountAndCustName(@RequestParam("merchantId") int merchantId,
			@RequestParam("transactionAmount") Double transactionAmount, @RequestParam("custName") String custName);

	List<CustomTransaction> findByMerchantId(@RequestParam("merchantId") Integer merchantId);

	@Query(value = "select * from transactions t where t.merchantid like %:merchantId% and transactionamount > :transactionAmount ", nativeQuery = true)
	List<CustomTransaction> findByMerchantIdAndTransactionAmount(@RequestParam("merchantId") int merchantId,
			@RequestParam("transactionAmount") Double transactionAmount);

	@Query(value = "select * from transactions t where t.merchantid like %:merchantId% and transactionamount >  :transactionAmount1 and transactionamount <  :transactionAmount2 and t.custname like %:custName% and t.pincode like %:pincode% ;", nativeQuery = true)
	List<CustomTransaction> findByMerchantIdAndTransactionAmountAndCustNameAndPincode(
			@RequestParam("merchantId") int merchantId, @RequestParam("transactionAmount1") Double transactionAmount1,
			@RequestParam("transactionAmount2") Double transactionAmount2, @RequestParam("custName") String custName,
			@RequestParam("pincode") Long pincode);

}
