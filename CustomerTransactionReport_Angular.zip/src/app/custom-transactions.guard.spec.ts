import { TestBed } from '@angular/core/testing';

import { CustomTransactionsGuard } from './custom-transactions.guard';

describe('CustomTransactionsGuard', () => {
  let guard: CustomTransactionsGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(CustomTransactionsGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
