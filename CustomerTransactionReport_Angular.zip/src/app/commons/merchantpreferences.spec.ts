import { Merchantpreferences } from './merchantpreferences';

describe('Merchantpreferences', () => {
  it('should create an instance', () => {
    expect(new Merchantpreferences()).toBeTruthy();
  });
});
