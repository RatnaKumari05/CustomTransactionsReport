export class Merchant {
      subscribe(arg0: (data: any) => void) {
        throw new Error('Method not implemented.')
      }


      public merchantId:number
      public merchantName:string
      public email:string
      public password:string

}
