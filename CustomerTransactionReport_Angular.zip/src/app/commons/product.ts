export class Product {

     

      public productId: number
      public productName: string
      public category: string
      public productCost: number
      public quantity:number

      constructor(){}
     

}
