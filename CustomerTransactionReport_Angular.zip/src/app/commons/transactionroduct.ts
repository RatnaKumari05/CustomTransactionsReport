export class Transactionroduct {

    public transProductId:number
    public transactionId:number
    public productId:number
    public quantity:number
   
   

}
