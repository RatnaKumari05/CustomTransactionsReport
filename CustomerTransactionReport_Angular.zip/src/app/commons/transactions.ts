import { Timestamp } from "rxjs"
import { Transactionroduct } from "./transactionroduct"

export class Transactions {

   

  public transactionId:number
  public custId:number
  public custName:string
  public merchantId:number
  public billingAddress:string
  public timeStamp:Date
  public pincode:number
  public transactionAmount:number
  public transactionCart :Transactionroduct[]
}
