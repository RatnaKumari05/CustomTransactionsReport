export class Merchantpreferences {



     constructor( 
      public merchantPrefId:number,
      public merchantId:number,
      public pincode:number,
      public upperLimit:number,
      public lowerLimit:number,
      public custName:string){}


}
