import { Transactionroduct } from './transactionroduct';

describe('Transactionroduct', () => {
  it('should create an instance', () => {
    expect(new Transactionroduct()).toBeTruthy();
  });
});
