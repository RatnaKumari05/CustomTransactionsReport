import { Transactions } from './transactions';

describe('Transactions', () => {
  it('should create an instance', () => {
    expect(new Transactions()).toBeTruthy();
  });
});
