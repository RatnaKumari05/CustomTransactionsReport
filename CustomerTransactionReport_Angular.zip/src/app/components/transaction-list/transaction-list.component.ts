import { JsonPipe } from '@angular/common';
import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Merchant } from 'src/app/commons/merchant';
import { Product } from 'src/app/commons/product';
import { Transactionroduct } from 'src/app/commons/transactionroduct';
import { Transactions } from 'src/app/commons/transactions';
import { CustomTransactionsService } from 'src/app/services/custom-transactions.service';
import { MechantService } from 'src/app/Services/mechant.service';
import { ProductService } from 'src/app/Services/product.service';
@Component({
  selector: 'app-transaction-list',
  templateUrl: './transaction-list.component.html',
  styleUrls: ['./transaction-list.component.css']
})

export class TransactionListComponent implements OnInit {

  merchantName: String
  merchantId: number
  merchants: Merchant[]
  transaction: Transactions[] = []
  transactioncart: Transactionroduct[]
  product: Product[]
  searchByName: String;
  searchById: number
  productId: number[]
  cost:number[]

  constructor(private service: CustomTransactionsService, private productservice: ProductService, private route: Router, private merchantservice: MechantService) { }


  ngOnInit(): void {
    this.getId()
    this.getAllTransactions(this.merchantId)
    this.amountForEachTransaction()

  }
  getName() {
    this.merchantName = this.merchantservice.merchant.merchantName

  }
  getId() {
    this.merchantId = this.merchantservice.merchant.merchantId

  }
  geCost() {
    this.cost= this.product.map(res =>{
      console.log(res.productCost)
      return res.productCost
    })

  }

  getAllTransactions(merchantId: number) {
    this.service.getcustomtransactions(merchantId).subscribe(data => {
      console.log(data)
      let responce = JSON.parse(JSON.stringify(data))

      this.transaction = responce
      this.getProductId()
    })

  }

  amountForEachTransaction(){

    for(var transact of this.transaction){
        transact.transactionCart.map(res =>{res.transProductId
        console.log(this.getProductCost(res.transProductId))

        })
    }

  }

  getProductCost(productId: number) {

     this.productservice.getCost(productId).subscribe(data =>{
      console.log(data)
      this.product=data
      return this.product
 
    })
  
  }

  getProductId() {
    for (var v = 0; v < this.transaction.length; v++) {


      this.transaction[v].transactionCart.map((tcart) => {
        console.log(tcart.transProductId)

        console.log(this.getProductCost(tcart.transProductId))

        return tcart.transProductId

      })

    }

  }

  ReportsONDate() {
    this.route.navigateByUrl("/showreports");
  }
}

