import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Transactions } from 'src/app/commons/transactions';
import { CustomTransactionsService } from 'src/app/services/custom-transactions.service';

@Component({
  selector: 'app-show-reports',
  templateUrl: './show-reports.component.html',
  styleUrls: ['./show-reports.component.css']
})
export class ShowReportsComponent implements OnInit {
  transactionList: Transactions[]
  selectedOption: string;
  options = [
    { name: "Product value report", value: 1 },
    { name: "Product volume report", value: 2 },
    { name: "Customer volume report", value: 3 },
    { name: "Customer value report", value: 4 },
    {name:"Complete Report", value: 5 }

  ]
  constructor(private service: CustomTransactionsService, private route: Router) { }

  ngOnInit(): void {


  }

  dateSubmit(showreports: any) {
    // console.log(showreports.startdate)
    this.service.getcustomtransactionsFromDateToDate(showreports.startdate, showreports.enddate).subscribe(data => {
      console.log(data)
      this.transactionList = data;
    })

  }

  transactionReportURL() {
    if (this.selectedOption === "Product value report") {
      this.route.navigateByUrl("/productvaluereport")
    }
    else if (this.selectedOption === "Product volume report") {
      this.route.navigateByUrl("/productvolumereport")

    }
    else if (this.selectedOption === "Customer volume report") {
      this.route.navigateByUrl("/customervolumereport")

    }
    else if (this.selectedOption === "Customer value report") {
      this.route.navigateByUrl("/customervaluereport")

    }
    else{
      this.route.navigateByUrl("/completereport")
    }

  
    


  }





}