import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerValueReportComponent } from './customer-value-report.component';

describe('CustomerValueReportComponent', () => {
  let component: CustomerValueReportComponent;
  let fixture: ComponentFixture<CustomerValueReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerValueReportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerValueReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
