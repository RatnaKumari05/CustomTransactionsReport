import { Component, OnInit } from '@angular/core';
import { Transactions } from 'src/app/commons/transactions';
import { CustomTransactionsService } from 'src/app/services/custom-transactions.service';
import { ProductService } from 'src/app/Services/product.service';

@Component({
  selector: 'app-product-value-report',
  templateUrl: './product-value-report.component.html',
  styleUrls: ['./product-value-report.component.css']
})
export class ProductValueReportComponent implements OnInit {

  transactionList : Transactions[]

  constructor(private service:CustomTransactionsService, private productService: ProductService) { }

  ngOnInit(): void {
   
  }


  dateSubmit(showreports:any){
    // console.log(showreports.startdate)
    this.service.getcustomtransactionsFromDateToDate(showreports.startdate,showreports.enddate).subscribe(data=>{
      console.log(data)
      this.transactionList = data;
    })

}

}

