import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductValueReportComponent } from './product-value-report.component';

describe('ProductValueReportComponent', () => {
  let component: ProductValueReportComponent;
  let fixture: ComponentFixture<ProductValueReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductValueReportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductValueReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
