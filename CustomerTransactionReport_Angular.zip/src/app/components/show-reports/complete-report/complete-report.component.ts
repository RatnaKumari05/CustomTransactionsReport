import { Component, OnInit } from '@angular/core';
import { Transactions } from 'src/app/commons/transactions';
import { CustomTransactionsService } from 'src/app/services/custom-transactions.service';

@Component({
  selector: 'app-complete-report',
  templateUrl: './complete-report.component.html',
  styleUrls: ['./complete-report.component.css']
})
export class CompleteReportComponent implements OnInit {

  
  transactionList : Transactions[]

  constructor(private service:CustomTransactionsService) { }

  ngOnInit(): void {
  }


  dateSubmit(showreports:any){
    // console.log(showreports.startdate)
    this.service.getcustomtransactionsFromDateToDate(showreports.startdate,showreports.enddate).subscribe(data=>{
      console.log(data)
      this.transactionList = data;
    })

}
}