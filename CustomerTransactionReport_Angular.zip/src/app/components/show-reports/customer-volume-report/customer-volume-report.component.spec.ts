import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerVolumeReportComponent } from './customer-volume-report.component';

describe('CustomerVolumeReportComponent', () => {
  let component: CustomerVolumeReportComponent;
  let fixture: ComponentFixture<CustomerVolumeReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerVolumeReportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerVolumeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
