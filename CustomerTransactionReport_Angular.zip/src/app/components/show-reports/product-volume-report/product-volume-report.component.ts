import { Component, OnInit } from '@angular/core';
import { Transactions } from 'src/app/commons/transactions';
import { CustomTransactionsService } from 'src/app/services/custom-transactions.service';

@Component({
  selector: 'app-product-volume-report',
  templateUrl: './product-volume-report.component.html',
  styleUrls: ['./product-volume-report.component.css']
})
export class ProductVolumeReportComponent implements OnInit {
  transactionList : Transactions[]

  constructor(private service:CustomTransactionsService) { }

  ngOnInit(): void {
  }


  dateSubmit(showreports:any){
    // console.log(showreports.startdate)
    this.service.getcustomtransactionsFromDateToDate(showreports.startdate,showreports.enddate).subscribe(data=>{
      console.log(data)
      this.transactionList = data;
    })

}

}
