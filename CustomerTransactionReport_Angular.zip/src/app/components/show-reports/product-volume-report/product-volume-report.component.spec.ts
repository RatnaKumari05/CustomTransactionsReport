import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductVolumeReportComponent } from './product-volume-report.component';

describe('ProductVolumeReportComponent', () => {
  let component: ProductVolumeReportComponent;
  let fixture: ComponentFixture<ProductVolumeReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductVolumeReportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductVolumeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
