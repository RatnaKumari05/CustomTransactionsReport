import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Merchant } from 'src/app/commons/merchant';
import { Merchantpreferences } from 'src/app/commons/merchantpreferences';
import { Product } from 'src/app/commons/product';
import { Transactionroduct } from 'src/app/commons/transactionroduct';
import { Transactions } from 'src/app/commons/transactions';
import { CustomTransactionsService } from 'src/app/services/custom-transactions.service';
import { MechantService } from 'src/app/Services/mechant.service';
import { MerchantpreferenceService } from 'src/app/Services/merchantpreference.service';

@Component({
  selector: 'app-transactions-filters',
  templateUrl: './transactions-filters.component.html',
  styleUrls: ['./transactions-filters.component.css']
})
export class TransactionsFiltersComponent implements OnInit {
  merchantName: String
  merchantId: number
  merchants: Merchant[]
  transaction: Transactions[];
  transactioncart: Transactionroduct[]
  filters: Merchantpreferences[]
  product: Product[]
  searchByName: String;
  searchById: number
  constructor(private route: Router, private service: CustomTransactionsService, private merchantservice: MechantService, private filterservice: MerchantpreferenceService) { }

  ngOnInit(): void {

    this.getAllfilters()
    this.getId()

    this.getAllTransactions(this.merchantId)

  }

  getName() {
    this.merchantName = this.merchantservice.merchant.merchantName

  }
  getId() {
    this.merchantId = this.merchantservice.merchant.merchantId

  }

  getAllTransactions(merchantId: number) {
    this.service.getcustomtransactions(merchantId).subscribe(data => {
      console.log(data)
      this.transaction = data
    })

  }


  ReportsONDate() {
    this.route.navigateByUrl("/showreports");
  }

  applyAllFilers() {
    for (var i = 0; i < this.filters.length; i++) {
      if (i == this.filters.length - 1) {



        if (this.filters[i].custName != "" && this.filters[i].pincode > 0 && this.filters[i].lowerLimit == 0 && this.filters[i].upperLimit == 0)
          console.log(this.getTransactionByPinandName(this.filters[i].merchantId, this.filters[i].custName, this.filters[i].pincode))

        if (this.filters[i].custName != "" && this.filters[i].pincode == 0 && this.filters[i].lowerLimit == 0 && this.filters[i].upperLimit == 0)
          console.log(this.GetTransactionByName(this.filters[i].merchantId, this.filters[i].custName))



        else if (this.filters[i].custName == "" && this.filters[i].pincode > 0 && this.filters[i].lowerLimit == 0 && this.filters[i].upperLimit == 0)
          console.log(this.GetTransactionBypinCode(this.filters[i].merchantId, this.filters[i].pincode))

        else
          console.log(this.getTransactionsByAllFilters(this.filters[i].merchantId, this.filters[i].lowerLimit, this.filters[i].upperLimit, this.filters[i].custName, this.filters[i].pincode))



      }
    }
  }





  getAllfilters() {
    this.filterservice.getAllFilters().subscribe(data => {
      console.log(data)
      this.filters = data
    })

  }
  updatFilter(merchantPrefId: number) {
    this.route.navigateByUrl("/filters/" + merchantPrefId)
  }


  DeleteFilter(merchantPrefId: number) {
    if (confirm("Do You wnat to delete the Filter?")) {
      this.filterservice.deleteFilter(merchantPrefId).subscribe(data => {
        console.log('deleted')
        this.getAllfilters()
      })
    }

  }
  filterdata() {
    this.route.navigateByUrl("/filter-data")
  }

  newfilters() {
    this.route.navigateByUrl("/filters")
  }

  GetTransactionByName(mid: number, custName: String) {

    this.filterservice.getDateeByName(mid, custName).subscribe(data => {
      console.log(data);
      this.transaction = data
    })
  }

  GetTransactionBypinCode(mid: number, pincode: number) {
    this.filterservice.getTransactionByPin(mid, pincode).subscribe(data => {
      console.log(data);
      this.transaction = data
    })


  }

  getTransactionByPinandName(mid: number, custName: String, pincode: number) {
    this.filterservice.getBymerchantIdPincodeandName(mid, custName, pincode).subscribe(data => {
      console.log(data);
      this.transaction = data
    })
  }

  getBylowerlimit(mid: number, amt: number) {
    this.filterservice.Bytransactionamount(mid, amt).subscribe(data => {
      console.log(data);
      this.transaction = data

    })
  }


  getByloweramountaAndname(mid: number, amount: number, name: string) {
    this.filterservice.getBytransactionamountandname(mid, amount, name).subscribe(data => {
      console.log(data);
      this.transaction = data
    })
  }

  getTransactionByLowerlimtAndNameAndPin(mid: number, amount: number, name: string, pin: number) {
    this.filterservice.getTransactionByLowerlimtAndNameAndPincode(mid, amount, name, pin).subscribe(data => {
      console.log(data);
      this.transaction = data
    })
  }

  getTransactionsByAllFilters(mid: number, amount1: number, amount2: number, name: string, pin: number) {

    this.filterservice.getTransactionsByAll(mid, amount1, amount2, name, pin).subscribe(data => {
      console.log(data);
      this.transaction = data
    })

  }
}


