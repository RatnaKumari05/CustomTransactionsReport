import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Merchantpreferences } from 'src/app/commons/merchantpreferences';
import { MerchantpreferenceService } from 'src/app/Services/merchantpreference.service';
import { MechantService } from 'src/app/Services/mechant.service';

@Component({
  selector: 'app-filters-list',
  templateUrl: './filters-list.component.html',
  styleUrls: ['./filters-list.component.css']
})
export class FiltersListComponent implements OnInit {



  filterID: number
  filters: Merchantpreferences = new Merchantpreferences(0, 0, 0, 0, 0, '')
  isEditable: boolean = false
  MerchantId: number

  constructor(private merservice: MechantService, private service: MerchantpreferenceService, private route: Router, private activateRoute: ActivatedRoute) { }

  ngOnInit(): void {

    this.activateRoute.paramMap.subscribe(() => { this.getFilterByID() })

  }

  getFilterByID() {

    const ID = +this.activateRoute.snapshot.paramMap.get("merchantId");
    console.log(ID)
    if (ID > 0) {
      this.isEditable = true
      this.service.getFilterById(ID).subscribe((data => {
        this.filters = data;
      }))
    }
  }
  getId() {
    this.MerchantId = this.merservice.merchant.merchantId
  }





  onsubmit() {
    // console.log(this.employee);
    if (this.isEditable) { // iseditable = true
      this.service.updateFilter(this.filters).subscribe(() => {
        this.route.navigateByUrl("/applyfilters")
      })

    } else {
      this.service.saveFilters(this.filters).subscribe(() => {
        this.route.navigateByUrl("/applyfilters")
      })
    }
  }
}



