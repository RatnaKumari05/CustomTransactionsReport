import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { CustomTransactionsGuard } from './custom-transactions.guard';
import { LoginComponent } from './login/login.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { TransactionListComponent } from './components/transaction-list/transaction-list.component';
import { FiltersListComponent } from './components/filters-list/filters-list.component';
import { TransactionsFiltersComponent } from './components/filters-list/transactions-filters/transactions-filters.component';
import { ShowReportsComponent } from './components/show-reports/show-reports.component';
import { CustomerValueReportComponent } from './components/show-reports/customer-value-report/customer-value-report.component';
import { CustomerVolumeReportComponent } from './components/show-reports/customer-volume-report/customer-volume-report.component';
import { CompleteReportComponent } from './components/show-reports/complete-report/complete-report.component';
import { ProductVolumeReportComponent } from './components/show-reports/product-volume-report/product-volume-report.component';
import { ProductValueReportComponent } from './components/show-reports/product-value-report/product-value-report.component';




const routes: Routes = [
  {path: '', component: AppComponent,
  children: [{path: '',component: LoginComponent}]},
  {path: 'welcome',canActivate:[CustomTransactionsGuard], component: WelcomeComponent},
  {path: 'login', component: LoginComponent},
  {path: 'Home', component: LoginComponent},
  {path : 'transactions' , component: TransactionListComponent},
  {path : 'filters' , component: FiltersListComponent},
  {path : 'applyfilters' , component: TransactionsFiltersComponent},
  {path : 'showreports' , component: ShowReportsComponent},
  {path:'filters/:merchantId',component:FiltersListComponent},
  {path : 'choosefilters',component :TransactionsFiltersComponent},
  {path:'productvaluereport',component:ProductValueReportComponent},
  {path:'customervaluereport',component:CustomerValueReportComponent},
  {path:'productvolumereport',component:ProductVolumeReportComponent},
  {path:'customervolumereport',component:CustomerVolumeReportComponent},
  {path:'completereport',component:CompleteReportComponent},
  {path:'delete/:empid',component:FiltersListComponent},





];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    WelcomeComponent,
    NavbarComponent,
    HeaderComponent,
    FooterComponent,
    TransactionListComponent,
    FiltersListComponent,
    TransactionsFiltersComponent,
    ShowReportsComponent,
    CustomerValueReportComponent,
    CustomerVolumeReportComponent,
    CompleteReportComponent,
    ProductVolumeReportComponent,
    ProductValueReportComponent,
   
  
 

  
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    FormsModule,
    HttpClientModule,
 
  ],
  providers: [],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})
export class AppModule { }
