import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Merchant } from '../commons/merchant';
import { MechantService } from '../Services/mechant.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {



  constructor(private route: Router, private merchantservice: MechantService, private activeRoute: ActivatedRoute) { }

  merchants: Merchant[] = [];

  ngOnInit(): void {
    this.activeRoute.paramMap.subscribe(() => {
      this.getAllMerchants();
    });
  }

  getAllMerchants() {
    this.merchantservice.getMerchantCredentials().subscribe(data => {
      console.log(data)
      this.merchants = data
    })

  }



  loginSubmit2(loginform: any) {
    var flag: boolean = true;
    for (var Merchant of this.merchants) {
      if ((loginform.email === Merchant.email) && (loginform.password === Merchant.password)) {
        
        this.merchantservice.merchant = (Merchant);
        console.log(Merchant.merchantName)
        this.merchantservice.setUserLoggedIn()
        flag = true;
        break;
      }
      else {
        flag = false;
      }
     

    }

    if(flag === true){
      this.route.navigateByUrl("/welcome");
    }
    else{
      alert("Invalid Credentials");
    }



  }
  




}


