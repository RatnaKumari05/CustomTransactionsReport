import { TestBed } from '@angular/core/testing';

import { CustomTransactionsService } from './custom-transactions.service';

describe('CustomTransactionsService', () => {
  let service: CustomTransactionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomTransactionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
