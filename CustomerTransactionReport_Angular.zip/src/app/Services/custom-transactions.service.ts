import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Transactionroduct } from '../commons/transactionroduct';
import { Transactions } from '../commons/transactions';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomTransactionsService {

merchantId:number
  transaction:Transactions
  


  constructor(private httpclient:HttpClient) { }

  getcustomtransactionsFromDateToDate(timestamp1:Date,timestamp2:Date) : Observable<Transactions[]>{
    const baseUrl=' http://localhost:8080/api/transactions/search/findByTimeStamp?timestamp1='+timestamp1+'&timestamp2='+timestamp2
    return this.httpclient.get<getTransactions>(baseUrl)
    .pipe(map(response => response._embedded.customTransactions));
  }
 

  getcustomtransactions(merchantId:number) : Observable<Transactions[]>{
    const baseUrl=' http://localhost:8080/api/transactions/search/findBymerchantId?merchantId='+merchantId
    return this.httpclient.get<getTransactions>(baseUrl)
    .pipe(map(response => response._embedded.customTransactions));
  }

  
}
interface getTransactions {
  _embedded : {
    customTransactions : Transactions[]
  }
}
