import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Product } from '../commons/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {



  constructor(private httpclient: HttpClient) { }

  getCost(productId: number): Observable<Product[]> {
    const baseurl = `http://localhost:8080/api/transactioncart/${productId}/product`
    return this.httpclient.get<Product[]>(baseurl);

  }


}



