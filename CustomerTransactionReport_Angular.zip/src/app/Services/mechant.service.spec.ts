import { TestBed } from '@angular/core/testing';

import { MechantService } from './mechant.service';

describe('MechantService', () => {
  let service: MechantService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MechantService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
