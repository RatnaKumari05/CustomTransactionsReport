import { TestBed } from '@angular/core/testing';

import { MerchantpreferenceService } from './merchantpreference.service';

describe('MerchantpreferenceService', () => {
  let service: MerchantpreferenceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MerchantpreferenceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
