import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Merchant } from '../commons/merchant';

@Injectable({
  providedIn: 'root'
})
export class MechantService {
  
merchant:Merchant
  isUserLoginValid = false;


  constructor(private httpclient: HttpClient) { 

  }

  getLoggedStatus() {
   
    return this.isUserLoginValid;
  }

  setUserLoggedIn() {
    this.isUserLoginValid = true;
  }

  setUserLoggedOut() {
    this.isUserLoginValid = false;
  }


  getMerchantCredentials(): Observable<Merchant[]> {
    const baseUrl = 'http://localhost:8080/api/loginCredentials'
    
    console.log( this.httpclient.get<getLogin>(baseUrl)
    .pipe(map(response => response._embedded.merchants)))
    return this.httpclient.get<getLogin>(baseUrl)
      .pipe(map(response => response._embedded.merchants));
    
      

  }
  

}

interface getLogin {
  _embedded: {
    merchants: Merchant[]
  }
}
