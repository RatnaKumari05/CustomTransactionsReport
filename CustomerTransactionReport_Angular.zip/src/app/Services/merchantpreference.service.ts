import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Merchantpreferences } from '../commons/merchantpreferences';
import { Transactions } from '../commons/transactions';

@Injectable({
  providedIn: 'root'
})
export class MerchantpreferenceService {

  isUserLoggedIn = false;
  baseUrl = "http://localhost:8080/api/merchantPreferences";



  constructor(private httpclient: HttpClient) { }



  getAllFilters(): Observable<Merchantpreferences[]> {


    return this.httpclient.get<getFiltersResponse>(this.baseUrl)
      .pipe(map(response => response._embedded.merchantPreferenceses));
  }



  saveFilters(filters: Merchantpreferences): Observable<Merchantpreferences> {
    console.log(filters)

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'auth-token',
        'Access-Control-Allow-Origin': '*'
      })
    }


    return this.httpclient.post<Merchantpreferences>(this.baseUrl, filters, httpOptions);
  }

  getFilterById(filterID: number): Observable<Merchantpreferences> {

    const filterIDURL = "http://localhost:8080/api/merchantPreferences/" + filterID

    return this.httpclient.get<Merchantpreferences>(filterIDURL);
  }

  updateFilter(filter: Merchantpreferences): Observable<Merchantpreferences> {
    console.log(filter)
    const filterMpidurl = "http://localhost:8080/api/merchantPreferences/search/findByMerchantId?merchantId="
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'auth-token',
        'Access-Control-Allow-Origin': '*'
      })
    }

    return this.httpclient.put<Merchantpreferences>(this.baseUrl + `/${filter.merchantId}`, filter, httpOptions)
  }

  deleteFilter(filterId: number): Observable<Merchantpreferences> {

    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json',
        'Authorization': 'auth-token',
        'Access-Control-Allow-Origin': '*'
      })
    }
    return this.httpclient.delete<Merchantpreferences>(this.baseUrl + `/${filterId}`, httpOptions);

  }

  getDateeByName(mid: number, name: String): Observable<Transactions[]> {

    const TransactionByNameUrl = `http://localhost:8080/api/transactions/search/findByMerchantIdAndCustName?merchantId=${mid}&custName=${name}`
    return this.httpclient.get<getTransactions>(TransactionByNameUrl).pipe(map(response => response._embedded.customTransactions))
  }

  getTransactionByPin(mid: number, pincode: number) {

    const findbypinUrl = `http://localhost:8080/api/transactions/search/findByMerchantIdAndPincode?merchantId=${mid}&pincode=${pincode}`
    return this.httpclient.get<getTransactions>(findbypinUrl).pipe(map(response => response._embedded.customTransactions))
  }

  getBymerchantIdPincodeandName(mid: number, name: String, pin: number) {
    const findbypinandNameUrl = `http://localhost:8080/api/transactions/search/findByMerchantIdAndPincodeAndCustName?merchantId=${mid}&pincode=${pin}&custName=${name}`
    return this.httpclient.get<getTransactions>(findbypinandNameUrl).pipe(map(response => response._embedded.customTransactions))

  }

  getBytransactionamountandname(mid: number, amount: number, name: string) {

    const url = `http://localhost:8080/api/transactions/search/findByMerchantIdAndTransactionAmountAndCustName?merchantId=${mid}&transactionAmount=${amount}&custName=${name}`
    return this.httpclient.get<getTransactions>(url).pipe(map(response => response._embedded.customTransactions))

  }
  getBytransactionamountandpin(mid: number, amount: number, pin: number) {
    const url = `http://localhost:8080/api/transactions/search/findByMerchantIdAndTransactionAmountAndPincode?merchantId=${mid}transactionAmount=${amount}pincode=${pin}`
    return this.httpclient.get<getTransactions>(url).pipe(map(response => response._embedded.customTransactions))
  }

  Bytransactionamount(mid: number, amount: number) {

    const url = `http://localhost:8080/api/transactions/search/findByMerchantIdAndTransactionAmount?merchantId=${mid}&transactionAmount=${amount}`
    return this.httpclient.get<getTransactions>(url).pipe(map(response => response._embedded.customTransactions))
  }

  getTransactionByLowerlimtAndNameAndPincode(mid: number, amount: number,name :String,pin:number) { 
    const url = `http://localhost:8080/api/transactions/search/findByMerchantIdAndTransactionAmountAndCustNameAndPincode?merchantId=${mid}&transactionAmount=${amount}&custName=${name}&pincode=${pin}`
    return this.httpclient.get<getTransactions>(url).pipe(map(response => response._embedded.customTransactions))
  }
getTransactionsByAll(mid :number,lowelimit:number,upperlimit:number,name:String,pin:number){
const url =  `http://localhost:8080/api/transactions/search/findByMerchantIdAndTransactionAmountAndCustNameAndPincode?merchantId=${mid}&transactionAmount1=${lowelimit}&transactionAmount2=${upperlimit}&custName=${name}&pincode=${pin}`
return this.httpclient.get<getTransactions>(url).pipe(map(response => response._embedded.customTransactions))
}
 
}
interface getFiltersResponse {
  _embedded: {
    merchantPreferenceses: Merchantpreferences[]
  }
}

interface getTransactions {
  _embedded: {
    customTransactions: Transactions[]
  }
}




