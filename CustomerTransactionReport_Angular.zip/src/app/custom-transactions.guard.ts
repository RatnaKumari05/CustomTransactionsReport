import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { MechantService } from './Services/mechant.service';

@Injectable({
  providedIn: 'root'
})
export class CustomTransactionsGuard implements CanActivate {
  constructor(private Service: MechantService){}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.Service.getLoggedStatus();
  }
  
}
