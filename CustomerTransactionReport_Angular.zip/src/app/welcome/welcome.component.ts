import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Merchant } from '../commons/merchant';
import { MechantService } from '../Services/mechant.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

merchantName:String
  constructor(private route: Router, private merchantservice: MechantService, private activeRoute: ActivatedRoute) { }
 
  
  ngOnInit(): void {
   this.getName()
  }

 getName(){
  this.merchantName=this.merchantservice.merchant.merchantName
  
 }
  
  LoginDetails(){
    this.route.navigateByUrl("/login")
  }

}
