package com.custom.transaction.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestParam;

import com.custom.transaction.entity.CustomTransaction;

@RepositoryRestResource(path = "transactions")
@CrossOrigin("http://localhost:4200/")
public interface CustomTransactionDAO extends JpaRepository<CustomTransaction, Integer> {
	@Query(value = "select * from transactions t where t.timestamps between  :timestamp1 and :timestamp2", nativeQuery = true)
	List<CustomTransaction> findByTimeStamp(@RequestParam("timestamp1") Timestamp timestamp1,
			@RequestParam("timestamp2") Timestamp timestamp2);

	@Query(value = "select * from transactions t where t.pincode like  %:pincode%", nativeQuery = true)
	List<CustomTransaction> findByPincode(@RequestParam("pincode") Long pincode);

	@Query(value = "select * from transactions t where t.custname like  %:custName%", nativeQuery = true)
	List<CustomTransaction> findByCustName(@RequestParam("custName") String custName);

}

//@Query(value = "select * from product p where p.proname like %:keyword% or p.category_id like %:keyword% ", nativeQuery = true)
//List<Product> findByKeyword(@Param("keyword") String keyword);

//@Query(value = "from EntityClassTable t where yourDate BETWEEN :startDate AND :endDate")
//public List<EntityClassTable> getAllBetweenDates(@Param("startDate")Date startDate,@Param("endDate")Date endDate);

//select * from transactions t1 inner join transactionproduct t2  on  t1.transactionid = t2.transactionid inner join  product p on p.productid = t2.productid;