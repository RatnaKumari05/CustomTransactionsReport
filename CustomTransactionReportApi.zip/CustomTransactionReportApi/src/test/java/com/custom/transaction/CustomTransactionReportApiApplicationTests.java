package com.custom.transaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomTransactionReportApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
